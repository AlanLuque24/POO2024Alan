package pe.edu.upeu.poo;

public class Application {
    public static void main(String[] args) {
        SysPooApplication.main(args);
    }
}
