<<<<<<<< HEAD:SysListasCRUD/src/test/java/pe/edu/upeu/SysListasCRUD/SysListasCrudApplicationTests.java
package pe.edu.upeu.SysListasCRUD;
========
package pe.edu.upeu.syscenterlife;
>>>>>>>> be58d28738f20add59528b260efb3df5ebb2d48b:SysVenCRUD/SysVenCRUD/src/test/java/pe/edu/upeu/syscenterlife/SysVenCrudApplicationTests.java

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
<<<<<<<< HEAD:SysListasCRUD/src/test/java/pe/edu/upeu/SysListasCRUD/SysListasCrudApplicationTests.java
class SysListasCrudApplicationTests {
========
class SysVenCrudApplicationTests {
>>>>>>>> be58d28738f20add59528b260efb3df5ebb2d48b:SysVenCRUD/SysVenCRUD/src/test/java/pe/edu/upeu/syscenterlife/SysVenCrudApplicationTests.java

	@Test
	void contextLoads() {
	}

}
