<<<<<<<< HEAD:SysListasCRUD/src/main/java/pe/edu/upeu/SysListasCRUD/SysListasCrudApplication.java
package pe.edu.upeu.SysListasCRUD;
========
package pe.edu.upeu.syscenterlife;
>>>>>>>> be58d28738f20add59528b260efb3df5ebb2d48b:SysVenCRUD/SysVenCRUD/src/main/java/pe/edu/upeu/syscenterlife/SysVenCrudApplication.java

import org.springframework.boot.SpringApplication;
import org.springframework.boot.autoconfigure.SpringBootApplication;

@SpringBootApplication
<<<<<<<< HEAD:SysListasCRUD/src/main/java/pe/edu/upeu/SysListasCRUD/SysListasCrudApplication.java
public class SysListasCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(SysListasCrudApplication.class, args);
========
public class SysVenCrudApplication {

	public static void main(String[] args) {
		SpringApplication.run(SysVenCrudApplication.class, args);
>>>>>>>> be58d28738f20add59528b260efb3df5ebb2d48b:SysVenCRUD/SysVenCRUD/src/main/java/pe/edu/upeu/syscenterlife/SysVenCrudApplication.java
	}

}
