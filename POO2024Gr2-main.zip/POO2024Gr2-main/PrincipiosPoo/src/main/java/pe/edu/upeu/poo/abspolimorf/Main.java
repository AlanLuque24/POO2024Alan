
package pe.edu.upeu.poo.abspolimorf;

public class Main {
    public static void main(String[] args) {
        Loro objLoro = new Loro();
        objLoro.animalSound();
        objLoro.sleep();
        
    }
    
}
