/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe.edu.upeu.poo.polimorfismo;


 
public class Main {
    public static void main(String[] args) {
        Loro objLoro=new Loro();
        objLoro.sonidoAnimal();
        
    }
    
    
}
