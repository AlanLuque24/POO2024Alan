/*
 * Click nbfs://nbhost/SystemFileSystem/Templates/Licenses/license-default.txt to change this license
 * Click nbfs://nbhost/SystemFileSystem/Templates/Classes/Class.java to edit this template
 */
package pe.edu.upeu.poo.herencia;

/**
 *
 * @author Datos
 */
public class Vehicle {

    protected String marca = "Ford"; //attribute

    protected void sonido() {//method
        System.out.println("Tuut, tuut!");
    }
}
