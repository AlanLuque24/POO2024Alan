package pe.edu.upeu.syscenterlife.modelo;

import lombok.Data;


@Data
public class Cliente {

    String dniruc;
    String nombres;
    String documento;
    
}
